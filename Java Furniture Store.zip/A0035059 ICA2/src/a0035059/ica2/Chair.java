/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;
import java.io.Serializable;
import javax.swing.*;
/**
 *
 * @author wills
 */
public class Chair extends Furniture implements Serializable {
    private String[] armrests = {"Armrests", "No Armrests"};
    private String armrestsChoice;
    private double[] armrestsUnits = {1875, 1625};
    private double chairUnits;
    
    /**
     * Default constructor, no parameters
     */
    Chair(){
        this.armrestsChoice = "No Armrests";
        this.chairUnits = 1650;
        image = new ImageIcon("chair.png");
    }
    
    /**
     * Constructor to create new chair items
     * @param rests
     * @param idNum
     * @param chooseWood
     * @param quantity 
     */
    public Chair(int rests, int idNum, int chooseWood, int quantity){
        super(idNum, chooseWood, quantity);
        this.armrestsChoice = armrests[rests];
        this.chairUnits = armrestsUnits[rests];
        image = new ImageIcon("chair.png");
    }
    
    
    /**
     * 
     * @return armrest choice as a string
     */
    public String getArmrestsChoice(){
        return armrestsChoice;
    }
    
    /**
     * Sets the armrest choice for the item
     * @param armrestsChoice 
     */
    public void setArmrestsChoice(String armrestsChoice){
        this.armrestsChoice = armrestsChoice;
        
        if(armrestsChoice.equals("Armrests"))
            chairUnits = 1875;
        else
            chairUnits = 1625;
    }
    
    
    /**
     * 
     * @return the price of the item as a double
     */
    @Override
    public double calcPrice(){
        itemPrice = (chairUnits * unitPrice) * quantity;
        return itemPrice;
    }
    
    /**
     * 
     * @return summary of the item as a string
     */
    @Override
    public String toString(){
        String chair = "CHAIR" + " | " + this.getIdNum() + "Wood: " + woodChoice + " | " + "Armrests: " + armrestsChoice + " | "+ 
                "Price: " + this.getItemPrice() + " | " + "Quantity: £" + this.getQuantity() + "\n";
                        
        
        return chair;
                        
    }
    
    
    
    
}
