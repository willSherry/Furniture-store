/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.GridLayout;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
/**
 *
 * @author wills
 */
public class GUI extends JPanel{
    
    public static ArrayList<Furniture> FurnitureList = new ArrayList<Furniture>();
    private ArrayList<Customer> CustomerList = new ArrayList<Customer>();
    private JLabel title, chairIcon, tableIcon, deskIcon, armrestOp, chairMatOp, tableMatOp, baseMat, diameterLabel;
    private JLabel deskWidth, deskDepth, deskDrawers, deskMaterial, chairTitle, enterChairID, enterChairQuantity;
    private JButton addCustomer, clearOrderButton, chairAddOrder, tableAddOrder, deskAddOrder, viewOrder;
    private JButton chairOrder;
    private ImageIcon chairPic, tablePic, deskPic; 
    public JCheckBox armrestBox;
    private JComboBox chairMaterial, baseMaterial, tableMat, deskMat, drawerOp;
    private String[] materialList = {"Walnut", "Oak"}, baseMatList = {"Wood", "Chrome"}, titleList = {"Mrs", "Ms", "Mr", "Mx"};
    private Integer[] drawerAmount = {1,2,3,4};
    public JTextField diameterInput, widthInput, depthInput, chairIDinput;
    private Color buttonBg = new Color(220, 220, 220);
    private JSpinner chairQuantity;
    public Customer newCustomer ;
    public Chair newChair;
    private int armrestChoice;
    public int chairTotalquantity;
    
    //implementing furniture classes
    Table table = new Table();
    Chair chair = new Chair();
    Desk desk = new Desk();
    Customer customer = new Customer();
    writeToFile customerFile = new writeToFile();
    
    
    
    GUI(){
        
        /*
        Setting up the main store page 
        */
        title = new JLabel("ROFC Official Store Page", SwingConstants.CENTER);
        title.setVisible(true);
        title.setOpaque(true);
        title.setBounds(0, 0, 1500, 150);
        title.setFont(new java.awt.Font("Rockwell", 0, 56));
        title.setForeground(Color.BLACK);
        //147, 187, 255
        Color titleBG = new Color(130, 108, 62);
        title.setBackground(titleBG);
        this.add(title);
        
        
        /*
        Setting up the Add New Customer Button
        */
        addCustomer = new JButton("Add New Customer");
        addCustomer.setBackground(buttonBg);
        addCustomer.addActionListener(new ActionListener(){
            
            /*
            Setting up the New Customer Button action listener 
            */
            public void actionPerformed(ActionEvent newCustomer){
                /*
                Creating the new customer menu JFrame
                */
                JFrame customerMenu = new JFrame("Customer Menu");
                customerMenu.setVisible(true);
                customerMenu.setSize(350, 400);
                customerMenu.setResizable(false);
                
                /*
                Creating the new customer menu JPanel
                */
                JPanel customerGUI = new JPanel();
                customerGUI.setLayout(null);
                customerMenu.add(customerGUI);
                
                /*
                Adding the customer menu GUI components
                */
                
                //Add Customer Title Label
                JLabel customerTitle = new JLabel("Add Customer", SwingConstants.CENTER);
                customerTitle.setVisible(true);
                customerTitle.setOpaque(true);
                customerTitle.setBounds(0, 0, 350, 50);
                customerTitle.setBackground(titleBG);
                customerTitle.setFont(new java.awt.Font("Rockwell", 0, 20));
                customerTitle.setForeground(Color.BLACK);
                customerGUI.add(customerTitle);
                
                //Customer ID Label
                JLabel cusID = new JLabel("Customer ID: ");
                cusID.setVisible(true);
                cusID.setBounds(30, 50, 100, 50);
                cusID.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(cusID);
                
                //Customer ID Input
                JTextField IDinput = new JTextField();
                IDinput.setVisible(true);
                IDinput.setBounds(210,65,130,20);
                customerGUI.add(IDinput);
                
                //Customer Title Label
                JLabel title = new JLabel("Title: ");
                title.setVisible(true);
                title.setBounds(30, 75, 100, 50);
                title.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(title);
                
                //Customer Title Input
                JComboBox titleInput = new JComboBox(titleList);
                titleInput.setVisible(true);
                titleInput.setBounds(210,90,130,20);
                customerGUI.add(titleInput);
                
                //Customer First Name Label
                JLabel cusFName = new JLabel("First Name: ");
                cusFName.setVisible(true);
                cusFName.setBounds(30, 100, 100, 50);
                cusFName.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(cusFName);
                
                //Customer First Name Input
                JTextField fNameInput = new JTextField();
                fNameInput.setVisible(true);
                fNameInput.setBounds(210,115,130,20);
                customerGUI.add(fNameInput);
                
                //Customer Last Name Label
                JLabel cusLName = new JLabel("Last Name: ");
                cusLName.setVisible(true);
                cusLName.setBounds(30, 125, 100, 50);
                cusLName.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(cusLName);
                
                //Customer Last Name Input
                JTextField lNameInput = new JTextField();
                lNameInput.setVisible(true);
                lNameInput.setBounds(210,140,130,20);
                customerGUI.add(lNameInput);
                
                //Customer Postcode Label
                JLabel postcode = new JLabel("Postcode: ");
                postcode.setVisible(true);
                postcode.setBounds(30, 150, 100, 50);
                postcode.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(postcode);
                
                //Customer Postcode Input
                JTextField postcodeInput = new JTextField();
                postcodeInput.setVisible(true);
                postcodeInput.setBounds(210,165,130,20);
                customerGUI.add(postcodeInput);
                
                //Customer Home Number/Name Label
                JLabel numberName = new JLabel("House Number/Name: ");
                numberName.setVisible(true);
                numberName.setBounds(30, 175, 150, 50);
                numberName.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(numberName);
                
                //Customer Home Number/Name Input
                JTextField numNameInput = new JTextField();
                numNameInput.setVisible(true);
                numNameInput.setBounds(210,192,130,20);
                customerGUI.add(numNameInput);
                
                //Customer Address Line 1 Label
                JLabel line1 = new JLabel("Address Line 1: ");
                line1.setVisible(true);
                line1.setBounds(30, 200, 125, 50);
                line1.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(line1);
                
                //Customer Address Line 1 Input
                JTextField line1Input = new JTextField();
                line1Input.setVisible(true);
                line1Input.setBounds(210,217,130,20);
                customerGUI.add(line1Input);
                
                //Customer Address Line 2 Label
                JLabel line2 = new JLabel("Address Line 2: ");
                line2.setVisible(true);
                line2.setBounds(30, 225, 125, 50);
                line2.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(line2);
                
                //Customer Address Line 2 Input
                JTextField line2Input = new JTextField();
                line2Input.setVisible(true);
                line2Input.setBounds(210,242,130,20);
                customerGUI.add(line2Input);
                
                //Customer Address Town/City Label
                JLabel townCity = new JLabel("Town/City: ");
                townCity.setVisible(true);
                townCity.setBounds(30, 250, 125, 50);
                townCity.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(townCity);
                
                //Customer Address Town/City Input
                JTextField townCityInput = new JTextField();
                townCityInput.setVisible(true);
                townCityInput.setBounds(210,268,130,20);
                customerGUI.add(townCityInput);
                
                //Customer Address County Label
                JLabel county = new JLabel("County: ");
                county.setVisible(true);
                county.setBounds(30, 275, 100, 50);
                county.setFont(new java.awt.Font("sansserif", 0, 15));
                customerGUI.add(county);
                
                //Customer Address County Input
                JTextField countyInput = new JTextField();
                countyInput.setVisible(true);
                countyInput.setBounds(210,293,130,20);
                customerGUI.add(countyInput);
                
                //Add Customer Button   
                JButton addCus = new JButton("Add Customer");
                addCus.setVisible(true);
                addCus.setBounds(100, 320, 120, 40);
                addCus.addActionListener(new ActionListener(){
                    
                    /**
                     * Adding the action listener to the New Customer Button
                     * @param customerAdded 
                     */
                    public void actionPerformed(ActionEvent customerAdded){
                            
                        /*
                        Adding the new customer to the customer database
                        */
                            try{
                            Customer newCustomer = new Customer(Integer.parseInt(IDinput.getText()), titleInput.getSelectedIndex(), fNameInput.getText(), lNameInput.getText(), postcodeInput.getText(), numNameInput.getText(), line1Input.getText(), line2Input.getText(), townCityInput.getText(), countyInput.getText());
                            CustomerList.add(newCustomer);
                            String customerDetails = newCustomer.toString();
                            try{
                                customerFile.writeFile(customerDetails);
                            } catch (IOException ex) {
                            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                        }
                            
                            /*
                            Chair Detail Input Validation
                            */
                            }catch(Exception exe){
                                
                                JOptionPane.showMessageDialog(null, "Please Input Valid Entries");
                                IDinput.setText(null);
                                titleInput.setSelectedIndex(0);
                                fNameInput.setText(null);
                                lNameInput.setText(null);
                                postcodeInput.setText(null);
                                numNameInput.setText(null);
                                line1.setText(null);
                                line2.setText(null);
                                townCity.setText(null);
                                county.setText(null);
                                
                            }
                            //Closing the customer menu window once customer has been added
                            customerMenu.dispatchEvent(new WindowEvent(customerMenu, WindowEvent.WINDOW_CLOSING));
                    }
                });
                
                customerGUI.add(addCus);
            }
        }
        );
        
        addCustomer.setBounds(50,210,150,80);
        addCustomer.setVisible(true);
        this.add(addCustomer, null);
        
        
        
        //Adding Table Image
        tablePic = new ImageIcon("table.png");
        tableIcon = new JLabel(tablePic);
        tableIcon.setVisible(true);
        tableIcon.setBounds(125, 375, 300, 350);
        this.add(tableIcon);
        
        //Adding Chair Image
        chairPic = new ImageIcon("chair.png");
        chairIcon = new JLabel(chairPic);
        chairIcon.setVisible(true);
        chairIcon.setBounds(575, 400, 300, 300);
        this.add(chairIcon);
        
        //Adding Desk Image
        deskPic = new ImageIcon("desk.png");
        deskIcon = new JLabel(deskPic);
        deskIcon.setVisible(true);
        deskIcon.setBounds(975, 400, 400, 300);
        this.add(deskIcon);
        
        //Adding Armrest Label
        armrestOp = new JLabel("Armrests");
        armrestOp.setVisible(true);
        armrestOp.setBounds(630, 680, 100, 100);
        armrestOp.setFont(new java.awt.Font("sansserif", 0, 20));
        this.add(armrestOp);
        
        //Armrest Option Input
        armrestBox = new JCheckBox();
        armrestBox.setVisible(true);
        armrestBox.setBounds(600, 715, 30, 30);
        armrestBox.setBackground(Color.LIGHT_GRAY);
        this.add(armrestBox);
        
        //Chair Material Input
        chairMaterial = new JComboBox(materialList);
        chairMaterial.setVisible(true);
        chairMaterial.setSelectedIndex(0);
        chairMaterial.setBounds(680, 745, 90, 25);
        this.add(chairMaterial);
        
        //Adding Chair Material Label
        chairMatOp = new JLabel("Material: ");
        chairMatOp.setVisible(true);
        chairMatOp.setBounds(600,707,100,100);
        chairMatOp.setFont(new java.awt.Font("sansserif", 0, 20));
        this.add(chairMatOp);
        
        //Adding Table Base Material Label
        baseMat = new JLabel("Base: ");
        baseMat.setVisible(true);
        baseMat.setBounds(95, 650, 100, 100);
        baseMat.setFont(new java.awt.Font("sansserif", 0, 20));
        this.add(baseMat);
        
        //Base Material Input
        baseMaterial = new JComboBox(baseMatList);
        baseMaterial.setVisible(true);
        baseMaterial.setSelectedIndex(0);
        baseMaterial.setBounds(160, 693, 75, 20);
        this.add(baseMaterial);
        
        //Table Diameter Input
        diameterInput = new JTextField();
        diameterInput.setVisible(true);
        diameterInput.setBounds(185,718,100,20);
        this.add(diameterInput);
        
        //Adding Table Diameter Label
        diameterLabel = new JLabel("Diameter: ");
        diameterLabel.setVisible(true);
        diameterLabel.setBounds(95, 675, 100, 100);
        diameterLabel.setFont(new java.awt.Font("sansserif", 0, 20));
        this.add(diameterLabel);
        
        //Adding Table Material Label
        tableMatOp = new JLabel("Material: ");
        tableMatOp.setVisible(true);
        tableMatOp.setBounds(95, 700, 100, 100);
        tableMatOp.setFont(new java.awt.Font("sansserif", 0, 20));
        this.add(tableMatOp);
        
        //Table Material Input
        tableMat = new JComboBox(materialList);
        tableMat.setVisible(true);
        tableMat.setSelectedIndex(0);
        tableMat.setBounds(175, 742, 75, 20);
        this.add(tableMat);
        
        //Table Width Input
        widthInput = new JTextField();
        widthInput.setVisible(true);
        widthInput.setBounds(1065, 710, 100, 20);
        this.add(widthInput);
        
        //Adding Desk Width Label
        deskWidth = new JLabel("Width: ");
        deskWidth.setVisible(true);
        deskWidth.setBounds(1000, 667, 100, 100);
        deskWidth.setFont(new java.awt.Font("sansserif", 0, 20));
        this.add(deskWidth);
        
        //Desk Depth Input
        depthInput = new JTextField();
        depthInput.setVisible(true);
        depthInput.setBounds(1065, 735, 100, 20);
        this.add(depthInput);

        //Adding Desk Depth Label
        deskDepth = new JLabel("Depth: ");
        deskDepth.setVisible(true);
        deskDepth.setBounds(1000,692, 100, 100);
        deskDepth.setFont(new java.awt.Font("sansserif", 0, 20));
        this.add(deskDepth);
        
        //Drawer Amount Input
        drawerOp = new JComboBox(drawerAmount);
        drawerOp.setVisible(true);
        drawerOp.setBounds(1065, 760, 75, 20);
        drawerOp.setSelectedIndex(0);
        this.add(drawerOp);
        
        //Adding Desk Drawer Amount Label
        deskDrawers = new JLabel("Drawers: ");
        deskDrawers.setVisible(true);
        deskDrawers.setFont(new java.awt.Font("sansserif", 0, 20));
        deskDrawers.setBounds(978, 717, 100, 100);
        this.add(deskDrawers);
        
        //Adding Desk Material Label
        deskMaterial = new JLabel("Material: ");
        deskMaterial.setFont(new java.awt.Font("sansserif", 0, 20));
        deskMaterial.setVisible(true);
        deskMaterial.setBounds(978,742,100,100);
        this.add(deskMaterial);
        
        //Desk Material Input
        deskMat = new JComboBox(materialList);
        deskMat.setVisible(true);
        deskMat.setBounds(1065, 785, 75, 20);
        this.add(deskMat);
        
        //Chair Add to Order Button
        chairAddOrder = new JButton("Add to Order");
        chairAddOrder.setVisible(true);
        chairAddOrder.setBackground(buttonBg);
        chairAddOrder.setBounds(600, 780, 120, 30);
        
        //Adding ActionListener to Chair Add to Order Button
        chairAddOrder.addActionListener(new ActionListener(){
            
            /**
             * Chair Add To Order Button Function
             * @param chairAddtoOrder 
             */
            public void actionPerformed(ActionEvent chairAddtoOrder){
                //Getting Armrest Input as Int
                if(armrestBox.isSelected()){
                    armrestChoice = 0;
                }
                else{
                    armrestChoice = 1;
                }
                
                //Creating Chair Add to Order Menu
                JFrame buyChair = new JFrame("Order Chair");
                buyChair.setVisible(true);
                buyChair.setSize(500, 300);
                buyChair.setResizable(false);
                
                //Creating Add to Order Menu panel
                JPanel chairGUI = new JPanel();
                buyChair.add(chairGUI);
                chairGUI.setLayout(null);
                
                //Adding a Chair Order Menu Title
                chairTitle = new JLabel("Add Chair to Order?", SwingConstants.CENTER);
                chairTitle.setVisible(true);
                chairTitle.setOpaque(true);
                chairTitle.setBounds(0, 0, 500, 50);
                chairTitle.setBackground(titleBG);
                chairTitle.setFont(new java.awt.Font("Rockwell", 0, 30));
                chairTitle.setForeground(Color.BLACK);
                chairGUI.add(chairTitle);
                
                //Chair Product ID Input
                chairIDinput = new JTextField();
                chairIDinput.setVisible(true);
                chairIDinput.setBounds(250, 100, 200, 40);
                chairGUI.add(chairIDinput);
                
                //Adding a Chair Product ID Label
                enterChairID = new JLabel("Enter Product ID:");
                enterChairID.setVisible(true);
                enterChairID.setBounds(20, 70, 200, 100);
                enterChairID.setFont(new java.awt.Font("sansserif", 0, 26));
                chairGUI.add(enterChairID);
                
                //Chair Quantity Input
                chairQuantity = new JSpinner();
                chairQuantity.setVisible(true);
                chairQuantity.setBounds(250, 150, 40, 40);
                chairGUI.add(chairQuantity);
                
                //Adding Chair Quantity Label
                enterChairQuantity = new JLabel("Quantity: ");
                enterChairQuantity.setVisible(true);
                enterChairQuantity.setBounds(115, 115, 200, 100);
                enterChairQuantity.setFont(new java.awt.Font("sansserif", 0, 26));
                chairGUI.add(enterChairQuantity);
                
                //Add Chair To Order Button
                chairOrder = new JButton("Add Chair(s) to Order!");
                chairOrder.setVisible(true);
                chairOrder.setBounds(150, 200, 200, 50);
                chairOrder.setBackground(buttonBg);
                
                //Adding the ActionListener to the Add Order Button
                chairOrder.addActionListener(new ActionListener(){
                    
                    /**
                     * Adding functionality to the Add Chair To Order Button
                     * @param chairBought 
                     */
                    public void actionPerformed(ActionEvent chairBought){
                        
                        /*
                        Adding the new chair to the order
                        */
                        try{
                            chairTotalquantity = (Integer) chairQuantity.getValue();
                            newChair = new Chair(armrestChoice,Integer.parseInt(chairIDinput.getText()),chairMaterial.getSelectedIndex(),chairTotalquantity);
                            FurnitureList.add(newChair);
                         
                        /*
                         Chair Detail Input Validation 
                        */
                        }catch(Exception exe){
                            
                            JOptionPane.showMessageDialog(null, "Please Input Valid Entries");
                            armrestBox.setSelected(false);
                            chairIDinput.setText(null);
                            chairMaterial.setSelectedIndex(0);
                            chairQuantity.setValue(0);
                        }
                        //Closes the Add Chair to order window
                        buyChair.dispatchEvent(new WindowEvent(buyChair, WindowEvent.WINDOW_CLOSING));
                    }
                });
                chairGUI.add(chairOrder);
            }   
        });
        
        this.add(chairAddOrder);
        
        //Table Add to Order Button
        tableAddOrder = new JButton("Add to Order");
        tableAddOrder.setVisible(true);
        tableAddOrder.setBackground(buttonBg);
        tableAddOrder.setBounds(95, 770, 120, 30);
        
        //Adding ActionListener to Table Add Order Button
        tableAddOrder.addActionListener(new ActionListener(){
            
            /**
             * Table Add to Order Button ActionListener functionality
             * @param tableAddtoOrder 
             */
            public void actionPerformed(ActionEvent tableAddtoOrder){
                
                //Creating Add Table to Order Menu
                JFrame buyTable = new JFrame("Order Table");
                buyTable.setVisible(true);
                buyTable.setSize(500, 300);
                buyTable.setResizable(false);
                
                //Creating Add Table to Order JPanel
                JPanel tableGUI = new JPanel();
                buyTable.add(tableGUI);
                tableGUI.setLayout(null);
                
                //Adding Title to  Add Table Menu
                JLabel tableTitle = new JLabel("Add Table to Order?", SwingConstants.CENTER);
                tableTitle.setVisible(true);
                tableTitle.setOpaque(true);
                tableTitle.setBounds(0, 0, 500, 50);
                tableTitle.setBackground(titleBG);
                tableTitle.setFont(new java.awt.Font("Rockwell", 0, 30));
                tableTitle.setForeground(Color.BLACK);
                tableGUI.add(tableTitle);
                
                //Table Product ID Input
                JTextField tableIDinput = new JTextField();
                tableIDinput.setVisible(true);
                tableIDinput.setBounds(250, 100, 200, 40);
                tableGUI.add(tableIDinput);
                
                //Adding Table Product ID Label
                JLabel enterTableID = new JLabel("Enter Product ID:");
                enterTableID.setVisible(true);
                enterTableID.setBounds(20, 70, 200, 100);
                enterTableID.setFont(new java.awt.Font("sansserif", 0, 26));
                tableGUI.add(enterTableID);
                
                //Table Quantity Input
                JSpinner tableQuantity = new JSpinner();
                tableQuantity.setVisible(true);
                tableQuantity.setBounds(250, 150, 40, 40);
                tableGUI.add(tableQuantity);
                
                //Adding Table Quantity Label
                JLabel enterTableQuantity = new JLabel("Quantity: ");
                enterTableQuantity.setVisible(true);
                enterTableQuantity.setBounds(115, 115, 200, 100);
                enterTableQuantity.setFont(new java.awt.Font("sansserif", 0, 26));
                tableGUI.add(enterTableQuantity);
                
                //Adding Add Table to Order Button
                JButton tableOrder = new JButton("Add Table(s) to Order!");
                tableOrder.setVisible(true);
                tableOrder.setBounds(150, 200, 200, 50);
                tableOrder.setBackground(buttonBg);
                
                //Adding ActionListener to Add Table to Order Button
                tableOrder.addActionListener(new ActionListener(){
                    
                    /**
                     * Add Table to Order Functionality
                     * @param tableBought 
                     */
                    @Override
                    public void actionPerformed(ActionEvent tableBought) {
                        
                        /*
                        Adding the Table to the order
                        */
                        try{
                            int quantity = (Integer) tableQuantity.getValue();
                            Table newTable = new Table(baseMaterial.getSelectedIndex(), Integer.parseInt(diameterInput.getText()), Integer.parseInt(tableIDinput.getText()), tableMat.getSelectedIndex(), quantity);
                            FurnitureList.add(newTable);
                        }catch(Exception exe){
                            /*
                            Add Table to Order Input Validation
                            */
                            JOptionPane.showMessageDialog(null, "Please Input Valid Entries");
                            baseMaterial.setSelectedIndex(0);
                            diameterInput.setText(null);
                            tableIDinput.setText(null);
                            tableMat.setSelectedIndex(0);
                            tableQuantity.setValue(0);
                        }
                        //Closing Add Table to Order Window
                        buyTable.dispatchEvent(new WindowEvent(buyTable, WindowEvent.WINDOW_CLOSING));
                    }
                });
                tableGUI.add(tableOrder);
                
            }
        });
        this.add(tableAddOrder);
        
        //Creating the Add Desk to Order Button
        deskAddOrder = new JButton("Add to Order");
        deskAddOrder.setVisible(true);
        deskAddOrder.setBackground(buttonBg);
        deskAddOrder.setBounds(980, 810, 120, 30);
        
        //Adding ActionListener to Add Desk to Order Button
        deskAddOrder.addActionListener(new ActionListener(){
            
            /**
             * Add Desk to Order Button Functionality
             * @param deskAddToOrder 
             */
            public void actionPerformed(ActionEvent deskAddToOrder){
                
                /*
                Creating the Add Desk to Order Menu
                */
                JFrame buyDesk = new JFrame("Order Table");
                buyDesk.setVisible(true);
                buyDesk.setSize(500, 300);
                buyDesk.setResizable(false);
                
                /*
                Creating the Add Desk to Order JPanel
                */
                JPanel deskGUI = new JPanel();
                buyDesk.add(deskGUI);
                deskGUI.setLayout(null);
                
                /*
                Adding Components to the Menu
                */
                
                //Add title to Desk Order Menu
                JLabel deskTitle = new JLabel("Add Desk to Order?", SwingConstants.CENTER);
                deskTitle.setVisible(true);
                deskTitle.setOpaque(true);
                deskTitle.setBounds(0, 0, 500, 50);
                deskTitle.setBackground(titleBG);
                deskTitle.setFont(new java.awt.Font("Rockwell", 0, 30));
                deskTitle.setForeground(Color.BLACK);
                deskGUI.add(deskTitle);
                
                //Desk Product ID Input
                JTextField deskIDinput = new JTextField();
                deskIDinput.setVisible(true);
                deskIDinput.setBounds(250, 100, 200, 40);
                deskGUI.add(deskIDinput);
                
                //Adding Desk Product ID Label
                JLabel enterDeskID = new JLabel("Enter Product ID:");
                enterDeskID.setVisible(true);
                enterDeskID.setBounds(20, 70, 200, 100);
                enterDeskID.setFont(new java.awt.Font("sansserif", 0, 26));
                deskGUI.add(enterDeskID);
                
                //Desk Quantity Input
                JSpinner deskQuantity = new JSpinner();
                deskQuantity.setVisible(true);
                deskQuantity.setBounds(250, 150, 40, 40);
                deskGUI.add(deskQuantity);
                
                //Adding Desk Quantity Label
                JLabel enterDeskQuantity = new JLabel("Quantity: ");
                enterDeskQuantity.setVisible(true);
                enterDeskQuantity.setBounds(115, 115, 200, 100);
                enterDeskQuantity.setFont(new java.awt.Font("sansserif", 0, 26));
                deskGUI.add(enterDeskQuantity);
                
                //Add Desk to Order Button
                JButton deskOrder = new JButton("Add Desk(s) to Order!");
                deskOrder.setVisible(true);
                deskOrder.setBounds(150, 200, 200, 50);
                deskOrder.setBackground(buttonBg);
                
                //Adding an ActionListener to the Add Desk to Order Button
                deskOrder.addActionListener(new ActionListener(){
                    
                    /**
                     * Add Desk to Order Functionality
                     * @param deskBought 
                     */
                    @Override
                    public void actionPerformed(ActionEvent deskBought) {
                        
                        /*
                        Adding the desk to the order
                        */
                        try{
                            int quantity = (Integer) deskQuantity.getValue();
                            Desk newDesk = new Desk(drawerOp.getSelectedIndex(), Integer.parseInt(depthInput.getText()), Integer.parseInt(widthInput.getText()), Integer.parseInt(deskIDinput.getText()), deskMat.getSelectedIndex(), quantity);
                            FurnitureList.add(newDesk);
                            
                         /*
                          Desk Detail Input Validation
                         */
                        }catch(Exception exe){
                            JOptionPane.showMessageDialog(null, "Please Input Valid Entries");
                            drawerOp.setSelectedIndex(0);
                            depthInput.setText(null);
                            widthInput.setText(null);
                            deskIDinput.setText(null);
                            deskMat.setSelectedIndex(0);
                            deskQuantity.setValue(0);
                        }
                        //Closing Add Desk to Order Window
                        buyDesk.dispatchEvent(new WindowEvent(buyDesk, WindowEvent.WINDOW_CLOSING));
                    }
                });
                deskGUI.add(deskOrder);
            }
        });
        this.add(deskAddOrder);
        
        //Creating a View Order Button
        viewOrder = new JButton("View Order");
        viewOrder.setVisible(true);
        viewOrder.setBackground(buttonBg);
        viewOrder.setBounds(250,840,150,80);
        
        //Adding ActionListener to View Order Button
        viewOrder.addActionListener(new ActionListener(){
            
            /**
             * View Order Button Functionality
             * @param viewOrder 
             */
            public void actionPerformed(ActionEvent viewOrder){
                
                //Linking viewOrder class to GUI class
                viewOrderGUI viewOrderMenu = new viewOrderGUI();
                
                /*
                Creating View Order Window
                */
                JFrame viewOrderFrame = new JFrame("Your Current Order");
                viewOrderFrame.setVisible(true);
                viewOrderFrame.setResizable(false);
                viewOrderFrame.setSize(1200, 900);
                viewOrderFrame.add(viewOrderMenu);
                
                /*
                Creating View Order Panel
                */
                GridLayout viewOrderLayout = new GridLayout(3,3,10,10);
                viewOrderMenu.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
                viewOrderMenu.setLayout(viewOrderLayout);
                viewOrderMenu.setVisible(true);
                
            }
            
        });
        this.add(viewOrder);
        
        //Creating a Clear Order Button
        clearOrderButton = new JButton("Clear Order");
        clearOrderButton.setVisible(true);
        clearOrderButton.setBounds(50,840,150,80);
        clearOrderButton.setBackground(buttonBg);
        
        //Adding an ActionListener to the Clear Order Button
        clearOrderButton.addActionListener(new ActionListener(){
            
            /**
             * Clear Order Button Functionality
             * @param clearOrder 
             */
            public void actionPerformed(ActionEvent clearOrder){
                //Emptying the Furniture List
                FurnitureList.clear();
                JOptionPane.showMessageDialog(null, "Order Cleared");
            }
        });
        this.add(clearOrderButton);
        
        
        
    }
    
}
