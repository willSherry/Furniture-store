/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author wills
 */
public class viewOrderGUI extends JPanel implements ActionListener {
    
    
    private JButton saveOrderButton, totalPriceButton, displayOrderButton;
    private JPanel buttonRow, titleRow, imageRow;
    private JLabel title, productID, productWood, productPrice, productQuantity, productIDInfo, productWoodInfo, productPriceInfo;
    private JLabel productQuantityInfo;
    private ImageIcon tablePic, chairPic, deskPic;
    private GUI mainGUI = new GUI();
    private int totalPrice, subjectID;
    private String orderFileName;
    private File file;
    String orderDetails = "";
    String fileNameInput ="";
    int chairAmount = 0, tableAmount = 0, deskAmount = 0, targetChair, targetTable, targetDesk;
    boolean chairFound, deskFound, tableFound;
    
    writeToFile orderFile = new writeToFile();
    Chair chair = new Chair();
    
    /**
     * Default GUI constructor, no parameters, used to construct the view order GUI
     */
    viewOrderGUI(){
    
        
        /*
        Creating the three main panels for the menu
        */
        buttonRow = new JPanel();
        titleRow = new JPanel();
        imageRow = new JPanel();

        /*
        Adding the JPanels
        */
        this.setLayout(new BorderLayout());
        this.setBackground(Color.GRAY);
        this.add(titleRow, BorderLayout.NORTH);
        this.add(imageRow, BorderLayout.CENTER);
        this.setSize(1200, 900);
        this.setVisible(true);
        this.add(buttonRow, BorderLayout.SOUTH);

        /*
        View Order Title Code
        */
        title = new JLabel("Your Order", SwingConstants.CENTER);
        title.setVisible(true);
        title.setOpaque(true);
        title.setFont(new java.awt.Font("Rockwell", 0, 56));
        title.setForeground(Color.BLACK);
        //147, 187, 255
        Color titleBG = new Color(130, 108, 62);
        title.setBackground(titleBG);
        this.add(title);

        /*
        Setting up the title row
        */
        titleRow.setVisible(true);
        titleRow.setPreferredSize(new Dimension(900,100));
        titleRow.setLayout(new GridLayout(1,1,10,10));
        titleRow.add(title);


        /*
        Setting up the button row
        */
        buttonRow.setVisible(true);
        buttonRow.setPreferredSize(new Dimension(900,100));
        GridLayout buttonLayout = new GridLayout(1,3,10,10);
        buttonRow.setLayout(buttonLayout);


        /*
        Adding the buttons to the buttons row
        */
        JButton[] buttons = new JButton[3];
        buttons[0] = totalPriceButton = new JButton("Total Price");
        buttons[1] = saveOrderButton = new JButton("Save Order");
        buttons[2] = displayOrderButton = new JButton("Display Order");

        for(JButton b : buttons){
            b.setVisible(true);
            b.setSize(300,100);
            b.addActionListener(this);
            buttonRow.add(b);
        }

        /*
        Setting up the image row panel
        */
        imageRow.setVisible(true);
        imageRow.setPreferredSize(new Dimension(900,100));
        imageRow.setBorder(BorderFactory.createEmptyBorder(3,3,3,3));
        imageRow.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        imageRow.setLayout(new GridLayout(1,3,10,10));
        
        for(Furniture f : mainGUI.FurnitureList){
            if(f.toString().contains("CHAIR")){
                chairAmount++;
            }
            else if(f.toString().contains("TABLE")){
                tableAmount++;
            }
            else if(f.toString().contains("DESK")){
                deskAmount++;
            }
        }
        
        /*
        Setting up the three furniture images for the image row
        */
        tablePic = new ImageIcon("tableViewOrder.png");
        JLabel tableIcon = new JLabel(tablePic);
        if(tableAmount == 0)
            tableIcon.setVisible(false);
        tableIcon.setBackground(Color.LIGHT_GRAY);
        tableIcon.setOpaque(true);
        imageRow.add(tableIcon);

        chairPic = new ImageIcon("chairViewOrder.png");
        JLabel chairIcon = new JLabel(chairPic);
        chairIcon.setBackground(Color.LIGHT_GRAY);
        chairIcon.setOpaque(true);
        if(chairAmount == 0)
            chairIcon.setVisible(false);
        imageRow.add(chairIcon);

        deskPic = new ImageIcon("deskAddOrder.png");
        JLabel deskIcon = new JLabel(deskPic);
        if(deskAmount == 0)
            deskIcon.setVisible(false);
        deskIcon.setBackground(Color.LIGHT_GRAY);
        deskIcon.setOpaque(true);
        imageRow.add(deskIcon);
        
        
        
        /*
        Setting up the mouse listeners for three images
        */
        
        /*
        Adding the mouse listener to the desk icon
        */
        deskIcon.addMouseListener(new MouseListener() {
            /**
             * Adds mouse listener to the desk picture
             * @param me 
             */
            @Override
            public void mouseClicked(MouseEvent me) {
                
                /*
                Sets up left mouse button functionality
                View Desk Details Feature
                */
                if(SwingUtilities.isLeftMouseButton(me)){
                     
                    /*
                    Creating the view desk details window
                    */
                    JFrame viewDesk = new JFrame("View Product Details");
                    viewDesk.setVisible(true);
                    viewDesk.setResizable(false);
                    viewDesk.setSize(500, 500);
                    
                    /*
                    Creating the panel for the view desk details window
                    */
                    JPanel deskDetails = new JPanel();
                    deskDetails.setLayout(new GridLayout(4,4,10,10));
                    deskDetails.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
                    deskDetails.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
                    deskDetails.setVisible(true);
                    viewDesk.add(deskDetails);
                    
                    /*
                    Adding the detail labels to the window
                    */
                    JLabel[] details = new JLabel[8];
                    details[0] = productID = new JLabel("Product ID: ");
                    details[1] = productIDInfo = new JLabel();
                    details[2] = productWood = new JLabel("Wood: ");
                    details[3] = productWoodInfo = new JLabel();
                    details[4] = productPrice = new JLabel("Price: ");
                    details[5] = productPriceInfo = new JLabel();
                    details[6] = productQuantity = new JLabel("Quantity: ");
                    details[7] = productQuantityInfo = new JLabel();
                    
                    for(JLabel l: details){
                        l.setVisible(true);
                        l.setBackground(Color.LIGHT_GRAY);
                        l.setOpaque(true);
                        l.setFont(new java.awt.Font("sansserif", 0, 26));
                        deskDetails.add(l);
                    }
                    
                    /*
                    Input validation for the table ID input 
                    */
                   try{
                       targetDesk = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Chair Product ID."));
                   }catch(Exception exe){
                       JOptionPane.showMessageDialog(null, "Please Only Enter Integers.");
                   }
                    
                   
                   /*
                   Loops through the furniture list to find the desk with the corresponding ID
                   */
                   for(Furniture f : mainGUI.FurnitureList){
                       deskFound = false;
                       if(f.toString().contains("DESK")){
                            
                           if(f.getIdNum() == targetDesk){
                                productIDInfo.setText(Integer.toString(f.getIdNum()));
                                productWoodInfo.setText(f.getWoodType());
                                productPriceInfo.setText("£" + Double.toString(f.calcPrice()));
                                productQuantityInfo.setText(Integer.toString(f.quantity));
                                deskFound = true;
                                break;
                            }
                           
                        }  
                   }
                   if(deskFound == false)
                       JOptionPane.showMessageDialog(null, "Unknown ID Entered.");
                }
                
                
                /**
                 * Setting up the right mouse button functionality
                 * Remove Desk from Order Feature
                 */
                else if(SwingUtilities.isRightMouseButton(me)){
                    
                    /*
                    Checking to see if the furniture list is empty
                    */
                    if(mainGUI.FurnitureList.isEmpty()){
                       JOptionPane.showMessageDialog(null, "There Are No Orders Currently Placed.");
                   }
                    
                   else{
                        
                        /*
                        Input validation for the table ID input
                        */
                        try{
                             subjectID = Integer.parseInt(JOptionPane.showInputDialog(null, "Please Enter ID of Desk to be Removed."));
                        }
                        catch(Exception exe){
                            JOptionPane.showMessageDialog(null, "Please Only Input Integers.");
                        }
                        
                        /*
                        Looping through the furniture list to find the subject table
                        */
                        for(Furniture f : mainGUI.FurnitureList){
                            deskFound = false;
                            
                            //Checks to see if the current object is a desk
                            if(f.toString().contains("DESK")){  
                                    
                                    //Checks to see if the current table is the subject table
                                    if(f.getIdNum() == subjectID){
                                        mainGUI.FurnitureList.remove(f);
                                        JOptionPane.showMessageDialog(null, "Item Removed.");
                                        deskAmount--;
                                        deskFound = true;
                                        break;
                                    }
                                
                            }
                        }
                        if(deskFound == false)
                            JOptionPane.showMessageDialog(null, "Unknown ID Entered");
                   }
                
                }
                
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                
            }
            
            /*
            Setting up the mouse-over functionality for table icon
            */
            @Override
            public void mouseEntered(MouseEvent me) {
                deskIcon.setBackground(Color.GRAY);
            }

            @Override
            public void mouseExited(MouseEvent me) {
                deskIcon.setBackground(Color.lightGray);
            }
        });
        
        
        
        
        chairIcon.addMouseListener(new MouseListener() {
            
            /**
             * Adds mouse listener to the chair picture
             * @param me 
             */
            @Override
            public void mouseClicked(MouseEvent me) {
                
                /*
                Sets up left mouse button functionality
                View Chair Details Feature
                */
                if(SwingUtilities.isLeftMouseButton(me)){
                    
                    /*
                    Creating the view chair details window
                    */
                    JFrame viewChair = new JFrame("View Product Details");
                    viewChair.setVisible(true);
                    viewChair.setResizable(false);
                    viewChair.setSize(500, 500);
                    
                    /*
                    Creating the panel for the view chair details window
                    */
                    JPanel chairDetails = new JPanel();
                    chairDetails.setLayout(new GridLayout(4,4,10,10));
                    chairDetails.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
                    chairDetails.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
                    chairDetails.setVisible(true);
                    viewChair.add(chairDetails);
                    
                    /*
                    Adding the detail windows to the window
                    */
                    JLabel[] details = new JLabel[8];
                    details[0] = productID = new JLabel("Product ID: ");
                    details[1] = productIDInfo = new JLabel();
                    details[2] = productWood = new JLabel("Wood: ");
                    details[3] = productWoodInfo = new JLabel();
                    details[4] = productPrice = new JLabel("Price: ");
                    details[5] = productPriceInfo = new JLabel();
                    details[6] = productQuantity = new JLabel("Quantity: ");
                    details[7] = productQuantityInfo = new JLabel();
                    
                    for(JLabel l: details){
                        l.setVisible(true);
                        l.setBackground(Color.LIGHT_GRAY);
                        l.setOpaque(true);
                        l.setFont(new java.awt.Font("sansserif", 0, 26));
                        chairDetails.add(l);
                    }
                    
                    /*
                    Input validation for the chair ID input
                    */
                   try{
                       targetChair = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Chair Product ID."));
                   }catch(Exception exe){
                       JOptionPane.showMessageDialog(null, "Please Only Enter Integers.");
                   }
                    
                   /*
                   Loops through the furniture list to find the chair with the corresponding ID
                   */
                   for(Furniture f : mainGUI.FurnitureList){
                       chairFound = false;
                       if(f.toString().contains("CHAIR")){
                            
                           if(f.getIdNum() == targetChair){
                                productIDInfo.setText(Integer.toString(f.getIdNum()));
                                productWoodInfo.setText(f.getWoodType());
                                productPriceInfo.setText("£" + Double.toString(f.calcPrice()));
                                productQuantityInfo.setText(Integer.toString(f.quantity));
                                chairFound = true;
                                break;
                            }
                           
                        }  
                   }
                   if(chairFound == false)
                       JOptionPane.showMessageDialog(null, "Unknown ID Entered.");
                }
                
                /**
                 * Setting up the right mouse button functionality
                 * Remove chair from Order Feature
                 */
                else if(SwingUtilities.isRightMouseButton(me)){
                   
                    /*
                    Checking to see if the furniture list is empty
                    */
                   if(mainGUI.FurnitureList.isEmpty()){
                       JOptionPane.showMessageDialog(null, "There Are No Orders Currently Placed.");
                   }
                   
                   else{
                       
                       /*
                       Input validation for the chair ID input 
                       */
                        try{
                             subjectID = Integer.parseInt(JOptionPane.showInputDialog(null, "Please Enter ID of Chair to be Removed."));
                        }
                        catch(Exception exe){
                            JOptionPane.showMessageDialog(null, "Please Only Input Integers.");
                        }
                        
                        /*
                        Looping through the furniture list to find the subject table
                        */
                        for(Furniture f : mainGUI.FurnitureList){
                            chairFound = false;
                            //Checks to make sure that current object is chair
                            if(f.toString().contains("CHAIR")){
                              
                                //Checks to see if current item is the target product
                                if(f.getIdNum() == subjectID){
                                    //removes item from FurnitureList
                                    mainGUI.FurnitureList.remove(f);
                                    JOptionPane.showMessageDialog(null, "Item Removed.");
                                    chairAmount--;
                                    chairFound = true;
                                    break;
                                }
                            }
                        }
                        if(chairFound == false){
                            JOptionPane.showMessageDialog(null, "Unknown ID Entered");
                        }
                        
                   }
                }
                
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
            }
            
            /*
            Setting up mouse-over functionality for chair icon
            */
            @Override
            public void mouseEntered(MouseEvent me) {
                chairIcon.setBackground(Color.GRAY);
            }

            @Override
            public void mouseExited(MouseEvent me) {
                chairIcon.setBackground(Color.lightGray);
            }
        });
        
        
        /*
        Adding the mouse listener to the table icon
        */
        tableIcon.addMouseListener(new MouseListener() {
            
            /**
             * Adds mouse listener to the table icon
             * @param me 
             */
            @Override
            public void mouseClicked(MouseEvent me) {
                
                /*
                Sets up left mouse buttom functionality
                View table details feature
                */
                if(SwingUtilities.isLeftMouseButton(me)){
                    
                    /*
                    Creating the view desk details window
                    */
                    JFrame viewTable = new JFrame("View Product Details");
                    viewTable.setVisible(true);
                    viewTable.setResizable(false);
                    viewTable.setSize(500, 500);
                    
                    /*
                    Creating the panel for the view desk details window
                    */
                    JPanel tableDetails = new JPanel();
                    tableDetails.setLayout(new GridLayout(4,4,10,10));
                    tableDetails.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
                    tableDetails.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
                    tableDetails.setVisible(true);
                    viewTable.add(tableDetails);
                    
                    /*
                    Adding the detail labels to the window
                    */
                    JLabel[] details = new JLabel[8];
                    details[0] = productID = new JLabel("Product ID: ");
                    details[1] = productIDInfo = new JLabel();
                    details[2] = productWood = new JLabel("Wood: ");
                    details[3] = productWoodInfo = new JLabel();
                    details[4] = productPrice = new JLabel("Price: ");
                    details[5] = productPriceInfo = new JLabel();
                    details[6] = productQuantity = new JLabel("Quantity: ");
                    details[7] = productQuantityInfo = new JLabel();
                    
                    for(JLabel l: details){
                        l.setVisible(true);
                        l.setBackground(Color.LIGHT_GRAY);
                        l.setOpaque(true);
                        l.setFont(new java.awt.Font("sansserif", 0, 26));
                        tableDetails.add(l);
                    }
                   
                    /*
                    Input validation for the table ID input
                    */
                   try{
                       targetDesk = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Table Product ID."));
                   }catch(Exception exe){
                       JOptionPane.showMessageDialog(null, "Please Only Enter Integers.");
                   }
                    
                   
                   /*
                   Loops through the furniture list to find the table with the correspoding ID
                   */
                   for(Furniture f : mainGUI.FurnitureList){
                       tableFound = false;
                       if(f.toString().contains("TABLE")){
                            if(f.getIdNum() == targetDesk){
                                productIDInfo.setText(Integer.toString(f.getIdNum()));
                                productWoodInfo.setText(f.getWoodType());
                                productPriceInfo.setText("£" + Double.toString(f.calcPrice()));
                                productQuantityInfo.setText(Integer.toString(f.quantity));
                                tableFound = true;
                                break;
                            }
                        }
                   }
                   if(tableFound == false)
                       JOptionPane.showMessageDialog(null, "Unknown ID Entered.");
                }
                
                
                /**
                 * Setting up right mouse button functionality
                 * Remove table from order feature
                 */
                else if(SwingUtilities.isRightMouseButton(me)){
                    if(mainGUI.FurnitureList.isEmpty()){
                       JOptionPane.showMessageDialog(null, "There Are No Orders Currently Placed.");
                   }
                   else{
                        /*
                        Input validation for the table ID input
                        */
                        try{
                             subjectID = Integer.parseInt(JOptionPane.showInputDialog(null, "Please Enter ID of Table to be Removed."));
                        }
                        catch(Exception exe){
                            JOptionPane.showMessageDialog(null, "Please Only Input Integers.");
                        }
                        
                        /*
                        Looping through the furniture list to find the subject table
                        */
                        for(Furniture f : mainGUI.FurnitureList){
                            tableFound = false;
                            //Checking to make sure the current object is a table
                            if(f.toString().contains("TABLE")){
                                //Checks to see if current item is the target product
                                if(f.getIdNum() == subjectID){
                                    mainGUI.FurnitureList.remove(f);
                                    JOptionPane.showMessageDialog(null, "Item Removed.");
                                    tableAmount--;
                                    tableFound = true;
                                    break;
                                }
                            }
                        }
                        if(tableFound == false)
                            JOptionPane.showMessageDialog(null, "Unknown ID Entered");
                   }
                
                }
                
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {

            }
            
            
            /*
            Setting up mous-over functionality for table icon
            */
            @Override
            public void mouseEntered(MouseEvent me) {
                tableIcon.setBackground(Color.GRAY);
            }

            @Override
            public void mouseExited(MouseEvent me) {
                tableIcon.setBackground(Color.lightGray);
            }
        });
        
        
        
       
    }
    
    
    /**
     * Write to file method, writes orderDetails to a new file
     * @param orderDetails
     * @throws IOException 
     */
    public void writeOrderFile(String orderDetails) throws IOException{
        file = new File(orderFileName+".txt");
        FileWriter fw = new FileWriter(file, true);
        try (PrintWriter pw = new PrintWriter(fw)) {
            pw.println(orderDetails);
            
        }
        
    }
    
    /**
     *
     * @param evt, TotalPrice button logic, save order to file button logic and load order from file button logic
     */
    public void actionPerformed(ActionEvent evt){
        if(evt.getSource() == totalPriceButton){
            totalPrice = 0;
            for(Furniture f : mainGUI.FurnitureList){
                totalPrice += f.calcPrice();
            }
            JOptionPane.showMessageDialog(null, "Total Price is £" + totalPrice);
        }
        
        
        /**
         * Save current order to file logic.
         */
        else if(evt.getSource() == saveOrderButton){
            
            orderFileName = JOptionPane.showInputDialog("Enter File Name");
            try{
                for(int i = 0; i < mainGUI.FurnitureList.size(); i++){
                    orderDetails += mainGUI.FurnitureList.get(i).toString();
                }
                this.writeOrderFile(orderDetails);
                JOptionPane.showMessageDialog(null, "Order Saved.");
            } catch(IOException ex) {
                
            }
        }
        
        /**
         *Display order button logic.
         */
        else if(evt.getSource() == displayOrderButton){
            
            String subjectFileName = JOptionPane.showInputDialog("Enter File Name.");
            ProcessBuilder pb = new ProcessBuilder("Notepad.exe", subjectFileName+".txt");
            try {
                pb.start();
            } catch (IOException ex) {
                Logger.getLogger(viewOrderGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
    
