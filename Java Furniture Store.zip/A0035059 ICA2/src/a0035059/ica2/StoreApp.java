/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.*;
/**
 *
 * @author wills
 */
public class StoreApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //creating the JPanel for the main GUI
        GUI guiPanel = new GUI();
        Dimension panelSize = new Dimension(1500, 1000);
        guiPanel.setPreferredSize(panelSize);
        
        //Creating the JFrame for the main GUI
        JFrame main = new JFrame("ROFC Store Page");
        main.setSize(1500, 1000);
        main.setResizable(false);
        main.setVisible(true);
        main.setDefaultCloseOperation(3);
        main.add(guiPanel);
        
        //Setting the layout of the JPanel
        guiPanel.setLayout(null);
        guiPanel.setBackground(Color.LIGHT_GRAY);
        
    }
    
}
