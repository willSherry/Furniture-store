/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;

/**
 *
 * @author wills
 */
public class Customer {
    private int customerID;
    private String firstName, lastName, postcode, numberName, line1, line2, townCity, county;
    private String[] titleList = {"Mrs", "Ms", "Mr", "Mx"};
    private String titleChoice;

    /**
     * Default constructor, no parameters.
     */
    Customer(){
        this.customerID = 9999;
        this.firstName = "Alex";
        this.lastName = "Lee";
        this.titleChoice = "Mx";
        this.postcode = "AB999CD";
        this.numberName = "9";
        this.line1 = "9 Place Street";
        this.line2 = "Area Avenue";
        this.townCity = "Location";
        this.county = "County Locale";
    }
   /**
    * Constructor used to create new customers with custom parameters
    * @param referenceNum
    * @param title
    * @param firstName
    * @param lastName
    * @param postcode
    * @param numberName
    * @param line1
    * @param line2
    * @param townCity
    * @param county 
    */
    public Customer(int referenceNum, int title, String firstName, String lastName, String postcode, String numberName, String line1, String line2, String townCity, String county){
        
        this.customerID = referenceNum;
        this.titleChoice = titleList[title];
        this.firstName = firstName;
        this.lastName = lastName;
        this.postcode = postcode;
        this.numberName = numberName;
        this.line1 = line1;
        this.line2 = line2;
        this.townCity = townCity;
        this.county = county;
        
    }
   
    /**
     * 
     * @return customer ID as integer 
     */
    public int getCustomerID(){
        return customerID;
    }
    
    /**
     * 
     * @return customer first name as a string
     */
    public String getFirstName(){
        return firstName;
    }
   
    /**
     * 
     * @return customer last name as a string
     */
    public String getLastName(){
        return lastName;
    }
    
    /**
     * 
     * @return customer postcode as a string
     */
    public String getPostcode(){
        return postcode;
    }
    
    /**
     * 
     * @return number/name of customer's home as a string
     */
    public String getNumberName(){
        return numberName;
    }
    
    /**
     * 
     * @return line 1 of customer's address as a string
     */
    public String getLine1(){
        return line1;
    }
    
    /**
     * 
     * @return line 2 of customer's address as a string
     */
    public String getLine2(){
        return line2;
    }
    
    /**
     * 
     * @return town/city of customer's address as a string
     */
    public String getTownCity(){
        return townCity;
    }
    
    /**
     * 
     * @return county of customer's address as a string
     */
    public String getCounty(){
        return county;
    }
    
    /**
     * 
     * @return title choice of customer as a string
     */
    public String getTitleChoice(){
        return titleChoice;
    }
    
    /**
     * Sets the customer ID 
     * @param customerID 
     */
    public void setCustomerID(int customerID){
        this.customerID = customerID;
    }
    
    /**
     * Sets the first name of the customer
     * @param firstName 
     */
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    /**
     * Sets the last name of the customer
     * @param firstName 
     */
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    
    /**
     * Sets the post code of the customer's address
     * @param postcode 
     */
    public void setPostcode(String postcode){
        this.postcode = postcode;
    }
    
    /**
     * Sets the number/name of the customer's address
     * @param numberName 
     */
    public void setNumberName(String numberName){
        this.numberName = numberName;
    }
    
    /**
     * Sets the first line of the customer's address
     * @param line1 
     */
    public void setLine1(String line1){
        this.line1 = line1;
    }
    
    /**
     * Sets the second line of the customer's address
     * @param line2 
     */
    public void setLine2(String line2){
        this.line2 = line2;
    }
    
    /**
     * Sets the town/city of the customer's address
     * @param townCity 
     */
    public void setTownCity(String townCity){
        this.townCity = townCity;
    }
    
    /**
     * Sets the county of the customer's address
     * @param county 
     */
    public void setCounty(String county){
        this.county = county;
    }
    
    @Override
    public String toString(){
        String customer =  customerID + " " + titleChoice + " " + firstName +
                " " + lastName + " " + postcode + " " + numberName + " " + line1 + " " + 
                line2 + " " + townCity + " " + county;
        return customer;
    }
}


