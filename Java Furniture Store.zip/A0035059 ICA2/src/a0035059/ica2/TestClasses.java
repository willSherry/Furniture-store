/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;

/**
 *
 * @author wills
 */
public class TestClasses {
    
    
    /**
     * Tests to make sure that the classes work as intended
     * @param args the command line argument
     */
    public static void main(String[] args){
        
        //Creating Chair objects
        Chair chair1 = new Chair();
        Chair chair2 = new Chair(0, 1, 1, 1);
        Chair chair3 = new Chair(1, 999, 0, 100);
        
        //Creating Table objects
        Table table1 = new Table();
        Table table2 = new Table(0, 50, 1, 1, 1);
        Table table3 = new Table(1, 100, 999, 1, 100);
        
        //Creating Desk Objects
        Desk desk1 = new Desk();
        Desk desk2 = new Desk(0, 50, 50, 1, 0, 1);
        Desk desk3 = new Desk(3, 100, 100, 999, 1, 100);
        
        //Creating Customer Objects
        Customer customer1 = new Customer();
        Customer customer2 = new Customer(1,0,"Will", "Sherry", "WS99 5SC", "Redwill House", "7 Redway Terrace", "Applebey Avenue", "Place City", "County");
        Customer customer3 = new Customer(999, 3, "FirstName", "LastName", "P05TC0D3", "HouseName/Number", "Line1", "Line2", "Town/City", "County");
        
        //Printing Chair Summary and Price
        System.out.println(chair1.toString());
        System.out.println("Chair 1 price: £" + chair1.calcPrice());
        System.out.println(chair2.toString());
        System.out.println("Chair 2 Price: £" + chair2.calcPrice());
        System.out.println(chair3.toString());
        System.out.println("Chair 3 Price: £" + chair3.calcPrice()); 
        
        //Printing Table Summary and Price
        System.out.println(table1.toString());
        System.out.println("Table 1 Price: £" + table1.calcPrice());
        System.out.println(table2.toString());
        System.out.println("Table 2 Price: £" + table2.calcPrice());
        System.out.println(table3.toString());
        System.out.println("Table 3 Price: £" + table3.calcPrice());
        
        //Printing Desk Summary and Price
        System.out.println(desk1.toString());
        System.out.println("Desk 1 Price: £" + desk1.calcPrice());
        System.out.println(desk2.toString());
        System.out.println("Desk 2 Price: £" + desk2.calcPrice());
        System.out.println(desk3.toString());
        System.out.println("Desk 3 Price: £" + desk3.calcPrice());
        
        //Printing Customer Summary
        System.out.println(customer1.toString());
        System.out.println(customer2.toString());
        System.out.println(customer3.toString());
        
    }
}
