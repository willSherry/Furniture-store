/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;
import java.io.Serializable;
import javax.swing.*;
/**
 *
 * @author wills
 */
public class Desk extends Furniture implements Serializable {
    private int[] drawerAmount = {1, 2, 3, 4};
    private int drawerChoice;
    private int depth;
    private int width;
    
    /**
     * Default constructor, no parameters.
     */
    Desk(){
        this.drawerChoice = 0;
        this.depth = 50;
        this.width = 80;
        image = new ImageIcon();
    }
    
    /**
     * Constructor, creates table
     * @param drawers
     * @param depth
     * @param width
     * @param idNum
     * @param chooseWood
     * @param quantity 
     */
    public Desk(int drawers, int depth, int width, int idNum, int chooseWood, int quantity){
        super(idNum, chooseWood, quantity);
        this.drawerChoice = drawerAmount[drawers];
        this.depth = depth;
        this.width = width;
        image = new ImageIcon();
    }
    
    /**
     * 
     * @return amount of drawers as an integer. 
     */
    public int getDrawerChoice(){
        return drawerChoice;
    }
    
    /**
     * 
     * @return depth of the desk as a double
     */
    public double getDepth(){
        return depth;
    }
    
    /**
     * 
     * @return width of the table as a double
     */
    public double getWidth(){
        return width;
    }
    
    /**
     * Sets the number of drawers of the desk
     * @param drawerChoice 
     */
    public void setDrawerChoice(int drawerChoice){
        this.drawerChoice = drawerChoice;
    }
    
    /**
     * Sets the depth of the desk
     * @param depth 
     */
    public void setDepth(int depth){
        this.depth = depth;
    }
    
    /**
     * Sets the width of the desk
     * @param width 
     */
    public void setWidth(int width){
        this.width = width;
    }
    
    /**
     * 
     * @return price of the desk as a double
     */
    @Override
    public double calcPrice(){
        itemPrice = ((depth * width * unitPrice) + (drawerChoice * 8.5)) * quantity;
        return itemPrice;
    }
    
    /**
     * 
     * @return summary of the item as a string
     */
    @Override
    public String toString(){
        String desk = "DESK" + " | " + "ID Number: " + this.getIdNum() + " | " + "Wood: " + woodChoice + " | " + 
                        "Depth: " + depth + " | " + "Width: " + width + " | " + "Drawers: " + drawerChoice + " | " + 
                "Price: " + this.getItemPrice() + " | " + "Quantity: " + this.getQuantity() + "\n";
        return desk;
    }
}
