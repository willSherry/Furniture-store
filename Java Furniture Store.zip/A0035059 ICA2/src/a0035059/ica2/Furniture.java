/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;

import java.io.Serializable;
import javax.swing.*;

/**
 *
 * @author wills
 */
public abstract class Furniture implements Serializable {
    private int idNum;
    private String[] woodType = {"Walnut", "Oak"};
    protected String woodChoice;
    protected double itemPrice;
    protected double unitPrice;
    protected int quantity;
    protected ImageIcon image;
    
    
    /**
     * Default Constructor, no parameters
     */
    Furniture(){
        this.idNum = 999;
        this.quantity = 1;
        this.woodChoice = "Walnut";
        this.unitPrice = 0.03;
    }
    
    
    /**
     * Constructor used to create furniture objects and set price using wood entered
     * @param idNum
     * @param chooseWood
     * @param quantity 
     */
    public Furniture(int idNum, int chooseWood, int quantity){
        this.idNum = idNum;
        this.woodChoice = woodType[chooseWood];
        this.quantity = quantity;
        
        if(woodChoice.equals(woodType[0])){
            unitPrice = 0.03;
        }
        else{
            unitPrice = 0.04;
        }
    }
    
    
    /**
     * 
     * @return ID Number of item as an am integer.
     */
    public int getIdNum(){
        return idNum;
    }
    
    /**
     * 
     * @return choice of wood of item as a string
     */
    public String getWoodType(){
        return woodChoice;
    }
    
    /**
     * 
     * @return item price as a double
     */
    public double getItemPrice(){
        return itemPrice;
    }
    
    /**
     * 
     * @return price per unit of item as a double
     */
    public double getUnitPrice(){
        return unitPrice;
    }
    
    /**
     * 
     * @return quantity of item ordered as an integer
     */
    public int getQuantity(){
        return quantity;
    }
    
    /**
     * 
     * @return the image related to the item as an ImageIcon
     */
    public ImageIcon getImage(){
        return image;
    }
    
    /**
     * Sets the price per unit for the item
     * @param unitPrice 
     */
    public void setUnitPrice(double unitPrice){
        this.unitPrice = unitPrice;
    }
    
    /**
     * Sets the ID number of the item
     * @param idNum 
     */
    public void setIdNum(int idNum){
        this.idNum = idNum;
    }
    
    /**
     * Sets the wood type of the item and the corresponding unit price
     * @param woodType 
     */
    public void setWoodType(String woodType){
        this.woodChoice = woodChoice;
        
        if(woodChoice == "Walnut"){
            unitPrice = 0.03;
        }
        else{
             unitPrice = 0.04;
        }
    }
    
    /**
     * Sets the price of the item
     * @param itemPrice 
     */
    public void setItemPrice(double itemPrice){
        this.itemPrice = itemPrice;
    }
    
    /**
     * Sets the quantity of the item
     * @param quantity 
     */
    public void setQuantity(int quantity){
        this.quantity = quantity;
    }
    
    /**
     * Sets the image of the item
     * @param image 
     */
    public void setImage(ImageIcon image){
        this.image = image;
    }
    
    @Override
    public abstract String toString();
    
    public abstract double calcPrice();
    
}
