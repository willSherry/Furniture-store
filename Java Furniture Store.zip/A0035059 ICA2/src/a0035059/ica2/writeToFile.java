/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

    /**
     *
     * @param customerDetails
     * @throws IOException
     */
public class writeToFile {
    
    
    
    public void writeFile(String customerDetails) throws IOException{
        File file = new File("Customer Database.txt");
        FileWriter fw = new FileWriter(file, true);
        try (PrintWriter pw = new PrintWriter(fw)) {
            pw.println(customerDetails);
            
        }
        
    }
    
}
