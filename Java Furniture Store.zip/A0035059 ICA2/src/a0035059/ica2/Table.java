/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a0035059.ica2;

import java.io.Serializable;
import javax.swing.*;
/**
 *
 * @author wills
 */
public class Table extends Furniture implements Serializable {
    private String[] baseTypes = {"Wooden", "Chrome"};
    private String baseChoice;
    private int diameter;
    private double basePrice;
    
    /**
     * Default Constructor, no parameters
     */
    Table(){
        this.baseChoice = "Wooden";
        this.diameter = 50;
        this.basePrice = 45.00;
        image = new ImageIcon();
    }
    
    /**
     * Constructor to create table items
     * @param base
     * @param diameter
     * @param idNum
     * @param chooseWood
     * @param quantity 
     */
    public Table(int base, int diameter, int idNum, int chooseWood, int quantity){
       
        super(idNum, chooseWood, quantity);
        this.baseChoice = baseTypes[base];
        this.diameter = diameter;
        image = new ImageIcon();
        
        if(baseChoice.equals("Wooden")){
            this.basePrice = 45.00;
        }
        
        else{
            this.basePrice = 35.00;
        }
    }
    
    /**
     * 
     * @return the base choice of the item as a string.
     */
    public String getBaseChoice(){
        return baseChoice;
    }
    
    /**
     * 
     * @return the diameter of the table as an integer.
     */
    public int getDiameter(){
        return diameter;
    }
    
    /**
     * 
     * @return the price of the base as a double.
     */
    public double getBasePrice(){
        return basePrice;
    }
    
    /**
     * Sets the base choice of the table.
     * @param baseChoice 
     */
    public void setBaseChoice(String baseChoice){
        this.baseChoice = baseChoice;
        
        if(baseChoice == "Wooden"){
            basePrice = 45.00;
        }
        else if(baseChoice == "Chrome"){
            basePrice = 35.00;
        }
    }
    
    /**
     * Sets the diameter of the table.
     * @param diameter 
     */
    public void setDiameter(int diameter){
        this.diameter = diameter;
        
        if(diameter < 50){
            this.diameter = 50;
        }
    }
    
    /**
     * Sets the price of the table base.
     * @param basePrice 
     */
    public void setBasePrice(double basePrice){
        this.basePrice = basePrice;
    }
    
    /**
     * 
     * @return the price of the table as a double.
     */
    @Override
    public double calcPrice(){
        itemPrice = (((diameter * diameter) * unitPrice) + basePrice) * quantity;
        return itemPrice;
    }
    
    /**
     * 
     * @return summary of the item as a string.
     */
    @Override
    public String toString(){
        String table = "TABLE" + " | " + "ID Number: " + this.getIdNum() + " | " + "Wood: " + woodChoice + 
                " | " + "Base Material: " + baseChoice + "Base Price: £" + basePrice + " | " 
                        +  "Diameter: " + diameter + " | " + "Quantity: " + this.getQuantity() + "\n";
        return table;
    }
    
}
